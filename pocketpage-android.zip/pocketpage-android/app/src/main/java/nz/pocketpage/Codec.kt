package nz.pocketpage

import android.nfc.NdefMessage
import android.nfc.NdefRecord
import java.io.ByteArrayOutputStream
import java.util.zip.DataFormatException
import java.util.zip.Deflater
import java.util.zip.Inflater

/**
 * Same format as the PocketPage web app, so codes/tags work in both.
 *   payload = raw DEFLATE of the page's UTF-8 HTML
 *   QR      = "PP1:" + base45(payload)       (QR alphanumeric mode)
 *   NFC     = MIME record application/x-pp   (bytes = payload)
 */
object Codec {
    const val QR_PREFIX = "PP1:"
    const val MIME = "application/x-pp"
    private const val MAX_HTML = 2 * 1024 * 1024 // guard against zip bombs

    fun deflate(html: String): ByteArray {
        val d = Deflater(Deflater.BEST_COMPRESSION, true)
        d.setInput(html.toByteArray(Charsets.UTF_8))
        d.finish()
        val out = ByteArrayOutputStream()
        val buf = ByteArray(4096)
        while (!d.finished()) {
            val n = d.deflate(buf)
            out.write(buf, 0, n)
        }
        d.end()
        return out.toByteArray()
    }

    fun inflate(zip: ByteArray): String {
        val inf = Inflater(true)
        inf.setInput(zip + byteArrayOf(0)) // nowrap mode wants a trailing dummy byte
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        try {
            while (!inf.finished()) {
                val n = inf.inflate(buf)
                if (n == 0 && (inf.needsInput() || inf.needsDictionary())) {
                    throw DataFormatException("data is cut short")
                }
                out.write(buf, 0, n)
                if (out.size() > MAX_HTML) throw DataFormatException("page too large")
            }
        } finally {
            inf.end()
        }
        return out.toString("UTF-8")
    }

    // ---- base45 (RFC 9285) ----
    private const val B45 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ \$%*+-./:"

    fun b45enc(u: ByteArray): String {
        val sb = StringBuilder()
        var i = 0
        while (i < u.size) {
            if (i + 1 < u.size) {
                val x = (u[i].toInt() and 255) * 256 + (u[i + 1].toInt() and 255)
                sb.append(B45[x % 45]).append(B45[(x / 45) % 45]).append(B45[x / 2025])
            } else {
                val a = u[i].toInt() and 255
                sb.append(B45[a % 45]).append(B45[a / 45])
            }
            i += 2
        }
        return sb.toString()
    }

    fun b45dec(s: String): ByteArray {
        fun idx(c: Char): Int = B45.indexOf(c).also { if (it < 0) throw IllegalArgumentException("bad character") }
        val out = ByteArrayOutputStream()
        var i = 0
        while (i < s.length) {
            if (i + 1 >= s.length) throw IllegalArgumentException("bad length")
            val c = idx(s[i])
            val d = idx(s[i + 1])
            if (i + 2 < s.length) {
                val x = c + d * 45 + idx(s[i + 2]) * 2025
                if (x > 0xFFFF) throw IllegalArgumentException("bad value")
                out.write(x shr 8)
                out.write(x and 255)
            } else {
                val x = c + d * 45
                if (x > 0xFF) throw IllegalArgumentException("bad value")
                out.write(x)
            }
            i += 3
        }
        return out.toByteArray()
    }

    // ---- NFC ----
    fun ndefMessage(zip: ByteArray) = NdefMessage(NdefRecord.createMime(MIME, zip))

    /** Bytes the tag must hold: NDEF message + TLV wrapper (4) + terminator (1). */
    fun tagBytesNeeded(zip: ByteArray) = ndefMessage(zip).byteArrayLength + 5

    fun findPayload(msgs: List<NdefMessage>): ByteArray? {
        for (m in msgs) for (r in m.records) {
            if (r.tnf == NdefRecord.TNF_MIME_MEDIA && String(r.type, Charsets.US_ASCII) == MIME) {
                return r.payload
            }
        }
        return null
    }
}
