package nz.pocketpage

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.nfc.tech.NdefFormatable
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.google.zxing.EncodeHintType
import com.google.zxing.WriterException
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.google.zxing.qrcode.encoder.Encoder
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

class MainActivity : ComponentActivity(), NfcAdapter.ReaderCallback {

    private lateinit var html: EditText
    private lateinit var sizeInfo: TextView
    private lateinit var qrInfo: TextView
    private lateinit var qrImage: ImageView
    private lateinit var btnSaveQr: Button
    private lateinit var nfcInfo: TextView

    private var nfc: NfcAdapter? = null
    @Volatile private var pendingWrite: ByteArray? = null
    private var qrBitmap: Bitmap? = null

    private val scanner = registerForActivityResult(ScanContract()) { result ->
        result.contents?.let { openFromQr(it) }
    }

    private val openFile = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            contentResolver.openInputStream(uri)?.use {
                html.setText(it.readBytes().toString(Charsets.UTF_8))
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        html = findViewById(R.id.html)
        sizeInfo = findViewById(R.id.sizeInfo)
        qrInfo = findViewById(R.id.qrInfo)
        qrImage = findViewById(R.id.qrImage)
        btnSaveQr = findViewById(R.id.btnSaveQr)
        nfcInfo = findViewById(R.id.nfcInfo)
        nfc = NfcAdapter.getDefaultAdapter(this)

        html.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = updateSizes()
        })
        if (savedInstanceState == null) html.setText(asset("tiny.html"))

        findViewById<Button>(R.id.btnFull).setOnClickListener { html.setText(asset("full.html")) }
        findViewById<Button>(R.id.btnTiny).setOnClickListener { html.setText(asset("tiny.html")) }
        findViewById<Button>(R.id.btnOpen).setOnClickListener { openFile.launch("text/*") }
        findViewById<Button>(R.id.btnPreview).setOnClickListener { openViewer(zip()) }
        findViewById<Button>(R.id.btnScan).setOnClickListener {
            scanner.launch(
                ScanOptions()
                    .setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                    .setPrompt("Point at a PocketPage QR code")
                    .setBeepEnabled(false)
                    .setOrientationLocked(false)
            )
        }
        findViewById<Button>(R.id.btnQr).setOnClickListener { makeQr() }
        btnSaveQr.setOnClickListener { saveQr() }
        findViewById<Button>(R.id.btnWrite).setOnClickListener {
            when {
                nfc == null -> nfcInfo.text = "This phone has no NFC."
                nfc?.isEnabled != true -> nfcInfo.text = "Turn NFC on in Settings first."
                else -> {
                    pendingWrite = zip()
                    nfcInfo.text = "Hold a tag to the back of the phone…"
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        nfc?.enableReaderMode(
            this, this,
            NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or
                NfcAdapter.FLAG_READER_NFC_F or NfcAdapter.FLAG_READER_NFC_V,
            null
        )
    }

    override fun onPause() {
        super.onPause()
        nfc?.disableReaderMode(this)
    }

    // ---------- helpers ----------
    private fun asset(name: String) = assets.open(name).use { it.readBytes().toString(Charsets.UTF_8) }.trim()

    private fun zip(): ByteArray = Codec.deflate(html.text.toString())

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun openViewer(zip: ByteArray) {
        startActivity(Intent(this, ViewerActivity::class.java).putExtra(ViewerActivity.EXTRA_ZIP, zip))
    }

    private fun updateSizes() {
        val raw = html.text.toString().toByteArray(Charsets.UTF_8).size
        if (raw == 0) { sizeInfo.text = ""; return }
        val z = zip()
        val need = Codec.tagBytesNeeded(z)
        fun fit(cap: Int) = if (need <= cap) "✓" else "✗"
        sizeInfo.text = "Raw $raw B → compressed ${z.size} B\n" +
            "NFC needs $need B:  NTAG213 ${fit(144)}   NTAG215 ${fit(504)}   NTAG216 ${fit(888)}"
    }

    // ---------- QR ----------
    private fun makeQr() {
        val text = Codec.QR_PREFIX + Codec.b45enc(zip())
        val code = try {
            Encoder.encode(text, ErrorCorrectionLevel.M, mapOf(EncodeHintType.MARGIN to 4))
        } catch (e: WriterException) {
            qrImage.setImageDrawable(null)
            qrInfo.text = "Too big for one QR code. Trim the page."
            btnSaveQr.isEnabled = false
            return
        }
        val m = code.matrix
        val quiet = 4
        val scale = 10
        val n = m.width + quiet * 2
        val px = IntArray(n * n) { Color.WHITE }
        for (y in 0 until m.height) for (x in 0 until m.width) {
            if (m.get(x, y).toInt() == 1) px[(y + quiet) * n + (x + quiet)] = Color.BLACK
        }
        val small = Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888)
        val bmp = Bitmap.createScaledBitmap(small, n * scale, n * scale, false)
        qrBitmap = bmp
        qrImage.setImageBitmap(bmp)
        btnSaveQr.isEnabled = true
        val v = code.version.versionNumber
        val hint = when {
            v <= 20 -> "easy scan"
            v <= 30 -> "print it large"
            else -> "very dense, hard to scan"
        }
        qrInfo.text = "Version $v (${m.width}×${m.width}), ${text.length} chars · $hint. " +
            "Print at least ${(m.width * 0.5 / 10).toInt() + 1} cm wide."
    }

    private fun saveQr() {
        val bmp = qrBitmap ?: return
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "pocketpage-${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PocketPage")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) { toast("Couldn't save"); return }
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        toast("Saved to Pictures/PocketPage")
    }

    private fun openFromQr(text: String) {
        if (!text.startsWith(Codec.QR_PREFIX)) { toast("That QR isn't a PocketPage."); return }
        try {
            openViewer(Codec.b45dec(text.substring(Codec.QR_PREFIX.length)))
        } catch (e: Exception) {
            toast("QR data is damaged.")
        }
    }

    // ---------- NFC (runs on a background thread) ----------
    override fun onTagDiscovered(tag: Tag) {
        val toWrite = pendingWrite
        if (toWrite != null) {
            pendingWrite = null
            val msg = try {
                "✓ Written (${writeTag(tag, toWrite)} bytes). Tap it again to test."
            } catch (e: Exception) {
                "✗ ${e.message ?: e.javaClass.simpleName}"
            }
            runOnUiThread { nfcInfo.text = msg }
            return
        }
        val ndef = Ndef.get(tag)
        val message = ndef?.cachedNdefMessage
        val payload = message?.let { Codec.findPayload(listOf(it)) }
        runOnUiThread {
            if (payload != null) openViewer(payload) else nfcInfo.text = "That tag has no PocketPage on it."
        }
    }

    private fun writeTag(tag: Tag, zip: ByteArray): Int {
        val msg = Codec.ndefMessage(zip)
        val size = msg.byteArrayLength
        Ndef.get(tag)?.let { ndef ->
            ndef.connect()
            try {
                if (!ndef.isWritable) throw IllegalStateException("Tag is locked / read-only")
                if (ndef.maxSize < size) {
                    throw IllegalStateException("Too big: page needs $size B, tag holds ${ndef.maxSize} B")
                }
                ndef.writeNdefMessage(msg)
            } finally {
                ndef.close()
            }
            return size
        }
        NdefFormatable.get(tag)?.let { f ->
            f.connect()
            try { f.format(msg) } finally { f.close() }
            return size
        }
        throw IllegalStateException("This tag type can't store NDEF data")
    }
}
