package nz.pocketpage

import android.app.Activity
import android.content.Intent
import android.nfc.NdefMessage
import android.nfc.NfcAdapter
import android.os.Build
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

/** Shows a page decoded from a QR code or NFC tag. Nothing touches the network. */
class ViewerActivity : Activity() {

    companion object {
        const val EXTRA_ZIP = "zip"
    }

    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.webViewClient = object : WebViewClient() {
            // Links on the page open in the phone's browser.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                } catch (_: Exception) {
                }
                return true
            }
        }
        show(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        show(intent)
    }

    private fun show(i: Intent) {
        val zip = i.getByteArrayExtra(EXTRA_ZIP) ?: fromNdef(i)
        if (zip == null) {
            fail("No PocketPage found on that tag")
            return
        }
        val html = try {
            Codec.inflate(zip)
        } catch (e: Exception) {
            fail("Page data is damaged: ${e.message}")
            return
        }
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
    }

    private fun fromNdef(i: Intent): ByteArray? {
        if (i.action != NfcAdapter.ACTION_NDEF_DISCOVERED) return null
        val raw: Array<*>? = if (Build.VERSION.SDK_INT >= 33) {
            i.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES, NdefMessage::class.java)
        } else {
            @Suppress("DEPRECATION")
            i.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES)
        }
        val msgs = raw?.filterIsInstance<NdefMessage>() ?: return null
        return Codec.findPayload(msgs)
    }

    private fun fail(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        finish()
    }
}
